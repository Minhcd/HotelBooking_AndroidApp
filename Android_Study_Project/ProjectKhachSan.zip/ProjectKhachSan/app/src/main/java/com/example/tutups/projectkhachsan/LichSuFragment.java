package com.example.tutups.projectkhachsan;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LichSuFragment extends Fragment {
    View v;
    RecyclerView lichsu_recyclerView;
    LichSuAdapter lichsuAdapter;
    ArrayList<LichSu> lichsuArrayList;
    RequestQueue requestQueue;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_lichsu, container, false);

        lichsu_recyclerView = v.findViewById(R.id.lichsu_recyclerView);
        lichsu_recyclerView.setHasFixedSize(true);
        lichsu_recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        lichsuArrayList = new ArrayList<>();

        lichsuAdapter = new LichSuAdapter(getActivity(), lichsuArrayList);
        lichsu_recyclerView.setAdapter(lichsuAdapter);
        requestQueue = Volley.newRequestQueue(getActivity());
        GetData();
        return v;
    }

    private void GetData() {
        //final String url = "http://192.168.1.16/android/DanhSachPhong.php";
        //final String url = "http://192.168.56.1/android/LichSu.php";
        final String url = "http://minh21298.000webhostapp.com/LichSu.php";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject object = response.getJSONObject(i);
                                String email = object.getString("email").toString().trim();
                                String hoten = object.getString("hoten");
                                String sodienthoai = object.getString("sodienthoai");
                                String loaiphong = object.getString("loaiphong");
                                String songuoi = object.getString("songuoi");
                                String sogiuong = object.getString("sogiuong");
                                String ngaynhan = object.getString("ngaynhan");
                                String ngaytra = object.getString("ngaytra");
                                String tienthue = object.getString("tienthue");
                                String tongtien = object.getString("tongtien");
                                String motaphong = object.getString("motaphong");
                                String thanhtoan = object.getString("thanhtoan");
                                String hinh = object.getString("hinh");
                                String thoihan = object.getString("thoihan");
                                String ngaydat = object.getString("ngaydat");
                                if (DangNhapActivity.Email.equals(email))
                                    lichsuArrayList.add(new LichSu(email, hoten, sodienthoai, loaiphong, songuoi, sogiuong, ngaynhan, ngaytra, tienthue, tongtien, motaphong, thanhtoan, hinh, thoihan, ngaydat));
                            } catch (JSONException e) {
                                Toast.makeText(getActivity(), "Lỗi: " + e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                        lichsuAdapter.notifyDataSetChanged();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Lỗi: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }
}
