package com.example.tutups.projectkhachsan;

public class Phong {
    private int id;
    private String tenloaiphong;
    private int songuoi;
    private String sogiuong;
    private int giatien;
    private String mota;
    private String tinhtrang;
    private String hinhURL;


    public Phong(int id, String tenloaiphong, int songuoi, String sogiuong, int giatien, String mota, String tinhtrang, String hinhURL) {
        this.id = id;
        this.tenloaiphong = tenloaiphong;
        this.songuoi = songuoi;
        this.sogiuong = sogiuong;
        this.giatien = giatien;
        this.mota = mota;
        this.tinhtrang = tinhtrang;
        this.hinhURL = hinhURL;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenloaiphong() {
        return tenloaiphong;
    }

    public void setTenloaiphong(String tenloaiphong) {
        this.tenloaiphong = tenloaiphong;
    }

    public int getSonguoi() {
        return songuoi;
    }

    public void setSonguoi(int songuoi) {
        this.songuoi = songuoi;
    }

    public String getSogiuong() {
        return sogiuong;
    }

    public void setSogiuong(String sogiuong) {
        this.sogiuong = sogiuong;
    }

    public int getGiatien() {
        return giatien;
    }

    public void setGiatien(int giatien) {
        this.giatien = giatien;
    }

    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }

    public String getTinhtrang() {
        return tinhtrang;
    }

    public void setTinhtrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }

    public String getHinhURL() {
        return hinhURL;
    }

    public void setHinhURL(String hinhURL) {
        this.hinhURL = hinhURL;
    }

}
