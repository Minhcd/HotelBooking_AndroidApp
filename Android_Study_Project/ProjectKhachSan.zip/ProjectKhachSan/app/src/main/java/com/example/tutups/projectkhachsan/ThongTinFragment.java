package com.example.tutups.projectkhachsan;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ThongTinFragment extends Fragment {
    TextView thongtin_textViewHoTen, thongtin_textViewDienThoai, thongtin_textViewEmail, thongtin_textViewDiaChi, thongtin_textViewTinhThanh;
    Button thongtin_buttonDoiMatKhau, thongtin_buttonSuaThongTin;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_thongtin, container, false);
        thongtin_textViewHoTen = view.findViewById(R.id.thongtin_textViewHoTen);
        thongtin_textViewDienThoai = view.findViewById(R.id.thongtin_textViewDienThoai);
        thongtin_textViewEmail = view.findViewById(R.id.thongtin_textViewEmail);
        thongtin_textViewDiaChi = view.findViewById(R.id.thongtin_textViewDiaChi);
        thongtin_textViewTinhThanh = view.findViewById(R.id.thongtin_textViewThanhTinh);
        thongtin_buttonDoiMatKhau = view.findViewById(R.id.thongtin_buttonDoiMatKhau);
        thongtin_buttonSuaThongTin = view.findViewById(R.id.thongtin_buttonSuaThongTin);
        Intent intent = getActivity().getIntent();
       /* final String user_email = intent.getStringExtra("user_email");
        final String user_pass = intent.getStringExtra("user_pass");*/
        GetUser();

        thongtin_buttonDoiMatKhau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogDoiMatKhau();
            }
        });

        thongtin_buttonSuaThongTin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogSuaThongTin();
            }
        });


        return view;
    }

    private void GetUser(){
        //String url = "http://192.168.1.16/android/ThongTinTaiKhoan.php";
        //String url = "http://192.168.56.1/android/ThongTinTaiKhoan.php";
        String url = "http://minh21298.000webhostapp.com/ThongTinTaiKhoan.php";
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            thongtin_textViewEmail.setText(object.getString("email"));
                            thongtin_textViewHoTen.setText(object.getString("hoten"));
                            thongtin_textViewDienThoai.setText(object.getString("dienthoai"));
                            thongtin_textViewDiaChi.setText(object.getString("diachi"));
                            thongtin_textViewTinhThanh.setText(object.getString("tinhthanh"));
                        } catch (JSONException e) {
                            Toast.makeText(getActivity(), e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_email", DangNhapActivity.Email);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void DialogDoiMatKhau(){
        final Dialog dialog = new Dialog(getActivity());
        //dòng này phải trước setContentView
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_doimatkhau);
        dialog.setCanceledOnTouchOutside(false);

        final EditText doimatkhau_editTextMatKhauHienTai = dialog.findViewById(R.id.doimatkhau_editTextMatKhauHienTai);
        final EditText doimatkhau_editTextMatKhauMoi = dialog.findViewById(R.id.doimatkhau_editTextMatKhauMoi);
        final EditText doimatkhau_editTextNhapLai = dialog.findViewById(R.id.doimatkhau_editTextNhapLai);
        Button doimatkhau_buttonThayDoi = dialog.findViewById(R.id.doimatkhau_buttonThayDoi);
        Button doimatkhau_buttonHuyBo = dialog.findViewById(R.id.doimatkhau_buttonHuyBo);

        doimatkhau_buttonThayDoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String matkhau = doimatkhau_editTextMatKhauHienTai.getText().toString().trim();
                String matkhaumoi = doimatkhau_editTextMatKhauMoi.getText().toString().trim();
                String nhaplai = doimatkhau_editTextNhapLai.getText().toString().trim();
                ArrayList<String> danhsach_loi = new ArrayList<>();
                if(matkhau.isEmpty() || matkhaumoi.isEmpty() || nhaplai.isEmpty()){
                    danhsach_loi.add("Vui lòng nhập đủ thông tin");
                }
                if(!matkhau.equals(DangNhapActivity.Pass)){
                    danhsach_loi.add("Mật khẩu hiện tại không đúng");
                }
                if(!matkhaumoi.equals(nhaplai)){
                    danhsach_loi.add("Nhập lại mật khẩu không đúng");
                }
                if(danhsach_loi.size() > 0){
                    StringBuilder stringBuilder = new StringBuilder();
                    for(int i = 0 ; i < danhsach_loi.size(); i++){
                        if(i == danhsach_loi.size()-1){
                            stringBuilder.append(danhsach_loi.get(i));
                        }else{
                            stringBuilder.append(danhsach_loi.get(i)+"\n");
                        }
                    }
                    Toast.makeText(getActivity(), stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                }else{
                    DoiMatKhau(matkhaumoi);
                    dialog.dismiss();
                }
            }
        });
        doimatkhau_buttonHuyBo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void DoiMatKhau(final String matkhaumoi){
        //String url = "http://192.168.1.16/android/DoiMatKhau.php";
        String url = "http://minh21298.000webhostapp.com/DoiMatKhau.php";
        //String url = "http://192.168.43.142/android/DoiMatKhau.php";
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.trim().equals("success")){
                            Toast.makeText(getActivity(), "Đổi mật khẩu thành công", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getActivity(), "Đổi mật khẩu thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", DangNhapActivity.Email);
                params.put("matkhaumoi", matkhaumoi);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void DialogSuaThongTin(){
        final Dialog dialogTT = new Dialog(getActivity());
        //dòng này phải trước setContentView
        dialogTT.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogTT.setContentView(R.layout.dialog_suathongtin);
        dialogTT.setCanceledOnTouchOutside(false);

        final EditText suathongtin_editTextHoTenMoi = dialogTT.findViewById(R.id.suathongtin_editTextHoTenMoi);
        final EditText suathongtin_editTextSDTMoi = dialogTT.findViewById(R.id.suathongtin_editTextSDTMoi);
        final EditText suathongtin_editTextDiaChiMoi = dialogTT.findViewById(R.id.suathongtin_editTextDiaChiMoi);
        final EditText suathongtin_editTextTinhThanhMoi = dialogTT.findViewById(R.id.suathongtin_editTextTinhThanhMoi);
        Button suathongtin_buttonThayDoi = dialogTT.findViewById(R.id.suathongtin_buttonThayDoi);
        Button suathongtin_buttonHuyBo = dialogTT.findViewById(R.id.suathongtin_buttonHuyBo);

        LoadThongTin(suathongtin_editTextHoTenMoi,suathongtin_editTextSDTMoi,suathongtin_editTextDiaChiMoi,suathongtin_editTextTinhThanhMoi);

        suathongtin_buttonThayDoi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hoten = suathongtin_editTextHoTenMoi.getText().toString().trim();
                String sdt = suathongtin_editTextSDTMoi.getText().toString().trim();
                String diachi = suathongtin_editTextDiaChiMoi.getText().toString().trim();
                String tinhthanh = suathongtin_editTextTinhThanhMoi.getText().toString().trim();
                ArrayList<String> danhsach_loi = new ArrayList<>();
                if(hoten.isEmpty() || sdt.isEmpty() || diachi.isEmpty() || tinhthanh.isEmpty()){
                    danhsach_loi.add("Vui lòng nhập đủ thông tin");
                }
                if(danhsach_loi.size() > 0){
                    StringBuilder stringBuilder = new StringBuilder();
                    for(int i = 0 ; i < danhsach_loi.size(); i++){
                        if(i == danhsach_loi.size()-1){
                            stringBuilder.append(danhsach_loi.get(i));
                        }else{
                            stringBuilder.append(danhsach_loi.get(i)+"\n");
                        }
                    }
                    Toast.makeText(getActivity(), stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                }else{
                    SuaThongTin(hoten, sdt, diachi, tinhthanh);
                    dialogTT.dismiss();
                }
            }
        });
        suathongtin_buttonHuyBo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogTT.dismiss();
            }
        });
        dialogTT.show();
    }

    private void SuaThongTin(final String hoten, final String sodienthoai, final String diachi, final String tinhthanh){
        //String url = "http://192.168.1.16/android/DoiMatKhau.php";
        String url = "http://minh21298.000webhostapp.com/SuaThongTin.php";
        //String url = "http://192.168.43.162/android/SuaThongTin.php";
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.trim().equals("success")){
                            Toast.makeText(getActivity(), "Sửa thông tin thành công", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getActivity(), "Sửa thông tin thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", DangNhapActivity.Email);
                params.put("hoten", hoten);
                params.put("sodienthoai", sodienthoai);
                params.put("diachi", diachi);
                params.put("tinhthanh", tinhthanh);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }

    private void LoadThongTin(final EditText hoten, final EditText sdt, final EditText diachi, final EditText tinhthanh){
        //String url = "http://192.168.1.16/android/ThongTinTaiKhoan.php";
        String url = "http://192.168.43.125/android/ThongTinTaiKhoan.php";
        //String url = "http://192.168.43.142/android/ThongTinTaiKhoan.php";
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            hoten.setText(object.getString("hoten"));
                            sdt.setText(object.getString("dienthoai"));
                            diachi.setText(object.getString("diachi"));
                            tinhthanh.setText(object.getString("tinhthanh"));
                        } catch (JSONException e) {
                            Toast.makeText(getActivity(), e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_email", DangNhapActivity.Email);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
