package com.example.tutups.projectkhachsan;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ThongBaoFragment extends Fragment {
    View v;
    RecyclerView thongbao_recyclerView;
    ThongBaoAdapter adapter;
    ArrayList<ThongBao> thongbaoArrayList;
    RequestQueue requestQueue;
    TextView txtSoLuong;
    TextView showNoti;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_thongbao,container,false);
        thongbao_recyclerView = v.findViewById(R.id.thongbao_recyclerView);
        thongbao_recyclerView.setHasFixedSize(true);
        thongbao_recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        txtSoLuong = v.findViewById(R.id.textViewSoLuongThongBao);
        showNoti = v.findViewById(R.id.textView24);
        thongbaoArrayList = new ArrayList<>();
        adapter = new ThongBaoAdapter(getActivity(),thongbaoArrayList);
        thongbao_recyclerView.setAdapter(adapter);
        requestQueue = Volley.newRequestQueue(getActivity());
        GetData();
        return v;

    }

    private void GetData() {
        final String url = "https://minh21298.000webhostapp.com/ShowUuDai.php";
        //final String url = "https://192.168.1.5/android.ShowUuDai.php";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i<response.length();i++) {
                            try {
                                JSONObject object = response.getJSONObject(i);
                                int ma = object.getInt("ID");
                                String nd = object.getString("noidung").toString();
                                thongbaoArrayList.add(new ThongBao(ma,nd));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                        txtSoLuong.setText(""+response.length());
                        showNoti.setText("Hiện có "+response.length()+" thông báo!");
                        adapter.notifyDataSetChanged();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(),"Error",Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(jsonArrayRequest);
    }
}
