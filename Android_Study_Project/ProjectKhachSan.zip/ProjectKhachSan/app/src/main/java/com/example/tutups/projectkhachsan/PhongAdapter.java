package com.example.tutups.projectkhachsan;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hrules.horizontalnumberpicker.HorizontalNumberPicker;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PhongAdapter extends RecyclerView.Adapter<PhongAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Phong> phongArrayList;
    //Tạo ViewHolder
    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;
        public TextView textViewSoNguoi, textViewSoGiuong, textViewTinhTrang, textViewGiaTien, textViewTenLoaiPhong;
        public LinearLayout layout;
        public Button buttonDatPhong;
        public HorizontalNumberPicker horizontalNumberPicker;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.item_imageViewItem);
            textViewSoNguoi = itemView.findViewById(R.id.item_textViewSoNguoi);
            textViewSoGiuong = itemView.findViewById(R.id.item_textViewSoGiuong);
            textViewTinhTrang = itemView.findViewById(R.id.item_textViewTinhTrang);
            textViewGiaTien = itemView.findViewById(R.id.item_textViewGiaTien);
            textViewTenLoaiPhong = itemView.findViewById(R.id.item_textViewTenLoaiPhong);
            layout = itemView.findViewById(R.id.item_layout);
            buttonDatPhong = itemView.findViewById(R.id.buttonDatPhong);
            horizontalNumberPicker = itemView.findViewById(R.id.item_numberPickerSoPhong);
        }
    }

    public PhongAdapter(Context context, ArrayList<Phong> phongArrayList) {
        this.context = context;
        this.phongArrayList = phongArrayList;
    }

    //3 hàm Override của Recycler View
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.dong_item, parent, false);
        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final Phong p = phongArrayList.get(position);
        holder.textViewSoNguoi.setText("Số người tối đa: "+p.getSonguoi());
        holder.textViewSoGiuong.setText(p.getSogiuong());
        holder.textViewTinhTrang.setText(p.getTinhtrang());
        holder.textViewGiaTien.setText(p.getGiatien()+"đ");
        holder.textViewTenLoaiPhong.setText(p.getTenloaiphong());
        holder.horizontalNumberPicker.setMinValue(1);
        holder.horizontalNumberPicker.setMaxValue(10);
        Picasso.get().load(p.getHinhURL()).fit().centerInside().into(holder.imageView);
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, p.getId()+": "+p.getTenloaiphong(), Toast.LENGTH_SHORT).show();
            }
        });
        holder.buttonDatPhong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ThanhToanActivity.class);
                intent.putExtra("sophong", holder.horizontalNumberPicker.getValue());
                intent.putExtra("loaiphong", p.getTenloaiphong());
                intent.putExtra("sogiuong", p.getSogiuong());
                intent.putExtra("mota", p.getMota());
                intent.putExtra("giatien", p.getGiatien());
                intent.putExtra("hinhURL",p.getHinhURL());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return phongArrayList.size();
    }
}
