package com.example.tutups.projectkhachsan;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class DanhSachPhongActivity extends AppCompatActivity {
    RecyclerView danhsach_recyclerView;
    PhongAdapter danhsach_phongAdapter;
    ArrayList<Phong> danhsach_phongArrayList;
    RequestQueue requestQueue;
    Toolbar danhsach_toolbar;
    EditText danhsach_editTextNgayNhan, danhsach_editTextNgayTra, danhsach_editTextSoNguoi;
    public static String SoNguoi, NgayNhan, NgayTra;
    public static Calendar NNgayNhan = TimPhongFragment.NgayNhan;
    public static Calendar NNgayTra = TimPhongFragment.NgayTra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_phong);
        //Ánh xạ các view
        danhsach_editTextNgayNhan = findViewById(R.id.danhsach_editTextNgayNhan);
        danhsach_editTextNgayTra = findViewById(R.id.danhsach_editTextNgayTra);
        danhsach_editTextSoNguoi = findViewById(R.id.danhsach_editTextSoNguoi);

        //Nhận dữ liệu từ TimPhongFragment
        Intent intent = getIntent();
        danhsach_editTextNgayNhan.setText(intent.getStringExtra("ngaynhan"));
        danhsach_editTextNgayTra.setText(intent.getStringExtra("ngaytra"));
        danhsach_editTextSoNguoi.setText(intent.getIntExtra("songuoi", 1) + "");
        NgayNhan = danhsach_editTextNgayNhan.getText().toString();
        NgayTra = danhsach_editTextNgayTra.getText().toString();
        SoNguoi = danhsach_editTextSoNguoi.getText().toString();
        //Set event click tạo DatePicker cho 2 edit text
        danhsach_editTextNgayNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgayNhan(danhsach_editTextNgayNhan);
                //NgayNhan = danhsach_editTextNgayNhan.getText().toString();
            }
        });

        danhsach_editTextNgayTra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgayTra(danhsach_editTextNgayTra);
                //NgayTra = danhsach_editTextNgayTra.getText().toString();
            }
        });

        danhsach_editTextSoNguoi.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                SoNguoi = danhsach_editTextSoNguoi.getText().toString();
            }
        });

        //Ánh xạ toolbar
        danhsach_toolbar = findViewById(R.id.danhsach_toolbar);
        danhsach_toolbar.setNavigationIcon(R.drawable.ic_back);
        danhsach_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //Xuất danh sách loại phòng
        danhsach_recyclerView = findViewById(R.id.danhsach_recyclerView);
        danhsach_recyclerView.setHasFixedSize(true);
        danhsach_recyclerView.setLayoutManager(new LinearLayoutManager(DanhSachPhongActivity.this));

        danhsach_phongArrayList = new ArrayList<>();

        danhsach_phongAdapter = new PhongAdapter(DanhSachPhongActivity.this, danhsach_phongArrayList);
        danhsach_recyclerView.setAdapter(danhsach_phongAdapter);
        requestQueue = Volley.newRequestQueue(DanhSachPhongActivity.this);
        GetData();
    }

    private void GetData() {
        //final String url = "http://192.168.1.16/android/DanhSachPhong.php";
        //final String url = "http://192.168.56.1/android/DanhSachPhong.php";
        final String url = "http://minh21298.000webhostapp.com/DanhSachPhong.php";
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject object = response.getJSONObject(i);
                                int id = object.getInt("idloaiphong");
                                String tenloaiphong = object.getString("tenloaiphong");
                                int songuoi = object.getInt("songuoi");
                                String sogiuong = object.getString("sogiuong");
                                int giatien = object.getInt("giatien");
                                String tinhtrang = object.getString("tinhtrang");
                                String urlhinh = object.getString("hinh");
                                String Mota = object.getString("mota");
                                //danhsach_phongArrayList.add(new Phong(id, tenloaiphong, songuoi, sogiuong, giatien, "", tinhtrang, urlhinh));
                                danhsach_phongArrayList.add(new Phong(id, tenloaiphong, songuoi, sogiuong, giatien, Mota, tinhtrang, urlhinh));
                            } catch (JSONException e) {
                                Toast.makeText(DanhSachPhongActivity.this, "Lỗi: " + e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                        danhsach_phongAdapter.notifyDataSetChanged();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(DanhSachPhongActivity.this, "Lỗi: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        );
        requestQueue.add(jsonArrayRequest);
    }

    private void ChonNgayNhan(final EditText editText) {
        final Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(DanhSachPhongActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                NNgayNhan.set(year,month,dayOfMonth);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
                editText.setText(simpleDateFormat.format(calendar.getTime()));
                NgayNhan = editText.getText().toString();
            }
        }, nam, thang, ngay);
        datePickerDialog.show();
    }

    private void ChonNgayTra(final EditText editText) {
        final Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(DanhSachPhongActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                NNgayTra.set(year,month,dayOfMonth);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
                editText.setText(simpleDateFormat.format(calendar.getTime()));
                NgayTra = editText.getText().toString();
            }
        }, nam, thang, ngay);
        datePickerDialog.show();
    }
}
