package com.example.tutups.projectkhachsan;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DangNhapActivity extends AppCompatActivity {
    Button dangnhap_buttonXacNhan, dangnhap_buttonTroVe;
    EditText dangnhap_editTextEmail, dangnhap_editTextMatKhau;
    CheckBox dangnhap_checkBoxNho;
    SharedPreferences sharedPreferences;
    public static String Email;
    public static String Pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_nhap);

        dangnhap_buttonXacNhan = findViewById(R.id.dangnhap_buttonXacNhan);
        dangnhap_buttonTroVe = findViewById(R.id.dangnhap_buttonTroVe);
        dangnhap_editTextEmail = findViewById(R.id.dangnhap_editTextEmail);
        dangnhap_editTextMatKhau = findViewById(R.id.dangnhap_editTextMatKhau);
        dangnhap_checkBoxNho = findViewById(R.id.dangnhap_checkBoxNho);

        sharedPreferences = getSharedPreferences("taikhoan_hientai", MODE_PRIVATE);

        dangnhap_editTextEmail.setText(sharedPreferences.getString("email", ""));
        dangnhap_editTextMatKhau.setText(sharedPreferences.getString("matkhau", ""));
        dangnhap_checkBoxNho.setChecked(sharedPreferences.getBoolean("nhomatkhau", false));

        dangnhap_buttonXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = dangnhap_editTextEmail.getText().toString().trim();
                String matkhau = dangnhap_editTextMatKhau.getText().toString().trim();
                ArrayList<String> danhsach_loi = new ArrayList<>();
                if(email.isEmpty() || matkhau.isEmpty()){
                    danhsach_loi.add("Vui lòng nhập đủ thông tin");
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    danhsach_loi.add("Email không hợp lệ");
                }
                if(danhsach_loi.size() > 0){
                    StringBuilder stringBuilder = new StringBuilder();
                    for(int i = 0 ; i < danhsach_loi.size(); i++){
                        if(i == danhsach_loi.size()-1){
                            stringBuilder.append(danhsach_loi.get(i));
                        }else{
                            stringBuilder.append(danhsach_loi.get(i)+"\n");
                        }
                    }
                    Toast.makeText(DangNhapActivity.this, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                }else{
                    DangNhap();
                }
            }
        });

        dangnhap_buttonTroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void DangNhap(){
        final RequestQueue requestQueue = Volley.newRequestQueue(DangNhapActivity.this);
        //String url = "http://192.168.1.16/android/DangNhapTaiKhoan.php";
        //String url = "http://192.168.56.1/android/DangNhapTaiKhoan.php";
        String url = "http://minh21298.000webhostapp.com/DangNhapTaiKhoan.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.trim().equals("success")){
                            if(dangnhap_checkBoxNho.isChecked()){
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("email", dangnhap_editTextEmail.getText().toString());
                                editor.putString("matkhau", dangnhap_editTextMatKhau.getText().toString());
                                editor.putBoolean("nhomatkhau", true);
                                editor.commit();
                            }else{
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.remove("email");
                                editor.remove("matkhau");
                                editor.remove("nhomatkhau");
                                editor.commit();
                            }
                            Email = dangnhap_editTextEmail.getText().toString();
                            Pass = dangnhap_editTextMatKhau.getText().toString();
                            Toast.makeText(DangNhapActivity.this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(DangNhapActivity.this, TimPhongActivity.class);
                            /*intent.putExtra("user_email", dangnhap_editTextEmail.getText().toString().trim());
                            intent.putExtra("user_pass", dangnhap_editTextMatKhau.getText().toString().trim());*/
                            startActivity(intent);

                        }else if(response.trim().equals("no_email")){
                            Toast.makeText(DangNhapActivity.this, "Email không tồn tại", Toast.LENGTH_SHORT).show();
                        }else if(response.trim().equals("wrong_password")){
                            Toast.makeText(DangNhapActivity.this, "Mật khẩu không đúng", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(DangNhapActivity.this, "Đăng nhập thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(DangNhapActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("emailTK", dangnhap_editTextEmail.getText().toString().trim());
                params.put("matkhauTK", dangnhap_editTextMatKhau.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
