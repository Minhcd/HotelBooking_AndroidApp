package com.example.tutups.projectkhachsan;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;


public class TimPhongActivity extends AppCompatActivity {
    ActionBarDrawerToggle timphong_drawertoggle;
    DrawerLayout timphong_drawerlayout;
    Toolbar timphong_toolbar;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tim_phong);

        timphong_toolbar = findViewById(R.id.timphong_toolbar);
        setSupportActionBar(timphong_toolbar);

        timphong_drawerlayout = findViewById(R.id.timphong_drawerlayout);
        NavigationView navigationView = findViewById(R.id.timphong_sidemenu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.sidemenu_timphong:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.timphong_fragment, new TimPhongFragment()).commit();
                        getSupportActionBar().setTitle("Tìm phòng");
                        break;
                    case R.id.sidemenu_thongtin:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.timphong_fragment, new ThongTinFragment()).commit();
                        getSupportActionBar().setTitle("Thông tin tài khoản");
                        break;
                    case R.id.sidemenu_lichsu:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.timphong_fragment, new LichSuFragment()).commit();
                        getSupportActionBar().setTitle("Lịch sử giao dịch");
                        break;
                    case R.id.sidemenu_thongbao:
                        getSupportFragmentManager().beginTransaction().replace(R.id.timphong_fragment, new ThongBaoFragment()).commit();
                        getSupportActionBar().setTitle("Thông báo");
                        break;
                    case R.id.sidemenu_hotro:
                        DialogHoTro();
                        break;
                    case R.id.sidemenu_vechungtoi:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.timphong_fragment, new VeChungToiFragment()).commit();
                        getSupportActionBar().setTitle("Về chúng tôi");
                        break;
                    case R.id.sidemenu_dangxuat:
                        sharedPreferences = getSharedPreferences("taikhoan_hientai",MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.remove("email");
                        editor.remove("matkhau");
                        editor.remove("nhomatkhau");
                        editor.commit();
                        startActivity(new Intent(TimPhongActivity.this, MainActivity.class));
                }
                item.setChecked(true);
                timphong_drawerlayout.closeDrawers();
                return true;
            }
        });

        timphong_drawertoggle = new ActionBarDrawerToggle(TimPhongActivity.this, timphong_drawerlayout, timphong_toolbar,
                R.string.mo_side_menu, R.string.dong_side_menu);
        timphong_drawerlayout.addDrawerListener(timphong_drawertoggle);
        timphong_drawertoggle.syncState();

        getSupportFragmentManager().beginTransaction().replace(R.id.timphong_fragment, new TimPhongFragment()).commit();
        navigationView.setCheckedItem(R.id.sidemenu_timphong);
        getSupportActionBar().setTitle("Tìm phòng");

    }

    @Override
    public void onBackPressed() {
        if (timphong_drawerlayout.isDrawerOpen(GravityCompat.START)) {
            timphong_drawerlayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void DialogHoTro(){
        final Dialog dialog = new Dialog(TimPhongActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_hotro);

        Button hotro_buttonTroVe = dialog.findViewById(R.id.hotro_buttonTroVe);
        hotro_buttonTroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
