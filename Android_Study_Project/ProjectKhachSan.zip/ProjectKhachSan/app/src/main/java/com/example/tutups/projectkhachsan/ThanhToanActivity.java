package com.example.tutups.projectkhachsan;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import android.support.v7.widget.Toolbar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class ThanhToanActivity extends AppCompatActivity {
    TextView Loaiphong;
    TextView Songuoi;
    TextView Sogiuong;
    TextView Giatien, Thue;
    TextView Ngaynhan, Ngaytra;
    Toolbar thanhtoan_toolbar;
    TextView thanhtoan_editTextEmail, thanhtoan_textViewSoPhong, thanhtoan_textViewThanhToan;
    EditText thanhtoan_editTextSDT, thanhtoan_editTextTenNguoiNhanPhong;
    Button buttonThanhToan;
    private static String thanhtoan = "Chưa thanh toán";
    public String HinhURL, Mota, nngaynhan, nngaytra, thoihan, ngaydat;
    public Calendar cal = Calendar.getInstance();
    public Calendar nngaydat = Calendar.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thanh_toan);

        thanhtoan_toolbar = findViewById(R.id.thanhtoan_toolbar);
        setSupportActionBar(thanhtoan_toolbar);
        getSupportActionBar().setTitle("Thanh toán");

        Loaiphong = findViewById(R.id.Loaiphong);
        Songuoi = findViewById(R.id.Songuoi);
        Sogiuong = findViewById(R.id.Sogiuong);
        Giatien = findViewById(R.id.Giatien);
        Ngaynhan = findViewById(R.id.Ngaynhan);
        Ngaytra = findViewById(R.id.Ngaytra);
        Thue = findViewById(R.id.Thue);
        thanhtoan_toolbar = findViewById(R.id.thanhtoan_toolbar);
        thanhtoan_toolbar.setNavigationIcon(R.drawable.ic_back);
        thanhtoan_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        thanhtoan_editTextEmail = findViewById(R.id.thanhtoan_editTextEmail);
        thanhtoan_editTextSDT = (EditText)findViewById(R.id.thanhtoan_editTextSDT);
        thanhtoan_editTextTenNguoiNhanPhong = (EditText)findViewById(R.id.thanhtoan_editTextTenNguoiNhanPhong);
        buttonThanhToan = (Button)findViewById(R.id.buttonThanhToan);
        thanhtoan_textViewSoPhong = findViewById(R.id.thanhtoan_textViewSoPhong);
        thanhtoan_textViewThanhToan = findViewById(R.id.thanhtoan_textViewThanhToan);
        //long diff = TimPhongFragment.NgayTra.getTimeInMillis() - TimPhongFragment.NgayNhan.getTimeInMillis();
        long diff = DanhSachPhongActivity.NNgayTra.getTimeInMillis() - DanhSachPhongActivity.NNgayNhan.getTimeInMillis();
        int days = (int) (diff/(1000*60*60*24));
        //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");

        Intent intent = getIntent();
        Loaiphong.setText(intent.getStringExtra("loaiphong"));
        Mota = intent.getStringExtra("mota");
        Sogiuong.setText(intent.getStringExtra("sogiuong"));
        int giatienphong =  intent.getIntExtra("giatien", 0)*days;
        HinhURL = intent.getStringExtra("hinhURL");
        int sophong = intent.getIntExtra("sophong",1);
        thanhtoan_textViewSoPhong.setText(sophong+"");
        final int Tongtien = giatienphong*sophong;
        int thue = (int)(Tongtien*0.15);
        final int ThanhTien = Tongtien+thue;
        //Giatien.setText(intent.getIntExtra("giatien", 0) + "");
        Giatien.setText(Tongtien+"đ");
        Thue.setText(thue+"đ");
        thanhtoan_textViewThanhToan.setText(ThanhTien+"đ");
        String ssonguoi = DanhSachPhongActivity.SoNguoi;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        nngaynhan = df.format(DanhSachPhongActivity.NNgayNhan.getTime());
        nngaytra = df.format(DanhSachPhongActivity.NNgayTra.getTime());

        Songuoi.setText(ssonguoi);
        Ngaynhan.setText(DanhSachPhongActivity.NgayNhan);
        Ngaytra.setText(DanhSachPhongActivity.NgayTra);
        thanhtoan_editTextEmail.setText(DangNhapActivity.Email);
        //thanhtoan_editTextTenNguoiNhanPhong.setText(ThongTinFragment.Hoten);
        //thanhtoan_editTextSDT.setText(ThongTinFragment.SoDienThoai);

        long th = cal.getTimeInMillis();
        thoihan = String.valueOf(th);
        LoadThongTin(thanhtoan_editTextTenNguoiNhanPhong,thanhtoan_editTextSDT);

        SimpleDateFormat dtf = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");
        ngaydat = dtf.format(nngaydat.getTime());

        buttonThanhToan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Email = thanhtoan_editTextEmail.getText().toString();
                String SDT = thanhtoan_editTextSDT.getText().toString();
                String Hoten = thanhtoan_editTextTenNguoiNhanPhong.getText().toString();
                ArrayList<String> danhsach_loi = new ArrayList<>();

                if(Email.isEmpty() || SDT.isEmpty()|| Hoten.isEmpty()){
                    danhsach_loi.add("Vui lòng nhập đủ thông tin");
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(Email).matches()){
                    danhsach_loi.add("Email không hợp lệ");
                }
                if(danhsach_loi.size() > 0){
                    StringBuilder stringBuilder = new StringBuilder();
                    for(int i = 0 ; i < danhsach_loi.size(); i++){
                        if(i == danhsach_loi.size()-1){
                            stringBuilder.append(danhsach_loi.get(i));
                        }else{
                            stringBuilder.append(danhsach_loi.get(i)+"\n");
                        }
                    }
                    Toast.makeText(ThanhToanActivity.this, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                }else{
                    ThanhToan();
                }
            }
        });
    }

    private void ThanhToan()
    {
        RequestQueue requestQueue = Volley.newRequestQueue(ThanhToanActivity.this);
        String url = "http://minh21298.000webhostapp.com/ThanhToan.php";
        //String url = "http://192.168.56.1/android/ThanhToan.php";
        //String url = "http://192.168.43.142/android/ThanhToan.php";
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(response.trim().equals("success")){
                    Toast.makeText(ThanhToanActivity.this, "Đặt phòng thành công", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ThanhToanActivity.this, TimPhongActivity.class));
                }else{
                    Toast.makeText(ThanhToanActivity.this, "Đặt phòng thất bại", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ThanhToanActivity.this, "Lỗi đặt phòng", Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> param = new HashMap<String, String>();
                param.put("Email", thanhtoan_editTextEmail.getText().toString().trim());
                param.put("HoTen", thanhtoan_editTextTenNguoiNhanPhong.getText().toString().trim());
                param.put("SDT", thanhtoan_editTextSDT.getText().toString().trim());
                param.put("LoaiPhong", Loaiphong.getText().toString().trim());
                param.put("SoNguoi", Songuoi.getText().toString().trim());
                param.put("SoGiuong", Sogiuong.getText().toString().trim());
                param.put("NgayNhan", nngaynhan);
                param.put("NgayTra", nngaytra);
                param.put("TienThue", Thue.getText().toString().trim());
                param.put("TongTien", thanhtoan_textViewThanhToan.getText().toString().trim());
                param.put("MoTa", Mota);
                param.put("ThanhToan", thanhtoan);
                param.put("HinhURL", HinhURL);
                param.put("ThoiHan",thoihan);
                param.put("SoPhong", thanhtoan_textViewSoPhong.getText().toString());
                param.put("NgayDat", ngaydat);
                return param;
            }
        };
        requestQueue.add(request);
    }

    private void LoadThongTin(final EditText hoten, final EditText sdt){
        //String url = "http://192.168.1.16/android/ThongTinTaiKhoan.php";
        String url = "http://minh21298.000webhostapp.com/ThongTinTaiKhoan.php";
        //String url = "http://192.168.43.142/android/ThongTinTaiKhoan.php";
        RequestQueue requestQueue = Volley.newRequestQueue(ThanhToanActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            hoten.setText(object.getString("hoten"));
                            sdt.setText(object.getString("dienthoai"));
                        } catch (JSONException e) {
                            Toast.makeText(ThanhToanActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ThanhToanActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_email", DangNhapActivity.Email);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
