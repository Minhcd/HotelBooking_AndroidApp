package com.example.tutups.projectkhachsan;

import java.util.Date;

public class LichSu {
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getSodienthoai() {
        return sodienthoai;
    }

    public void setSodienthoai(String sodienthoai) {
        this.sodienthoai = sodienthoai;
    }

    public String getLoaiphong() {
        return loaiphong;
    }

    public void setLoaiphong(String loaiphong) {
        this.loaiphong = loaiphong;
    }

    public String getSonguoi() {
        return songuoi;
    }

    public void setSonguoi(String songuoi) {
        this.songuoi = songuoi;
    }

    public String getSogiuong() {
        return sogiuong;
    }

    public void setSogiuong(String sogiuong) {
        this.sogiuong = sogiuong;
    }

    public String getNgaynhan() {
        return ngaynhan;
    }

    public void setNgaynhan(String ngaynhan) {
        this.ngaynhan = ngaynhan;
    }

    public String getNgaytra() {
        return ngaytra;
    }

    public void setNgaytra(String ngaytra) {
        this.ngaytra = ngaytra;
    }

    public String getTienthue() {
        return tienthue;
    }

    public void setTienthue(String tienthue) {
        this.tienthue = tienthue;
    }

    public String getTongtien() {
        return tongtien;
    }

    public void setTongtien(String tongtien) {
        this.tongtien = tongtien;
    }

    public String getMotaphong() {
        return motaphong;
    }

    public void setMotaphong(String motaphong) {
        this.motaphong = motaphong;
    }

    public String getThanhtoan() {
        return thanhtoan;
    }

    public void setThanhtoan(String thanhtoan) {
        this.thanhtoan = thanhtoan;
    }

    public String getHinh() {
        return hinh;
    }

    public void setHinh(String hinh) {
        this.hinh = hinh;
    }

    public LichSu(String email, String hoten, String sodienthoai, String loaiphong, String songuoi, String sogiuong, String ngaynhan, String ngaytra, String tienthue, String tongtien, String motaphong, String thanhtoan, String hinh, String thoihan, String ngaydat) {
        this.email = email;
        this.hoten = hoten;
        this.sodienthoai = sodienthoai;
        this.loaiphong = loaiphong;
        this.songuoi = songuoi;
        this.sogiuong = sogiuong;
        this.ngaynhan = ngaynhan;
        this.ngaytra = ngaytra;
        this.tienthue = tienthue;
        this.tongtien = tongtien;
        this.motaphong = motaphong;
        this.thanhtoan = thanhtoan;
        this.hinh = hinh;
        this.thoihan = thoihan;
        this.ngaydat = ngaydat;
    }

    private String email;
    private String hoten;
    private String sodienthoai;
    private String loaiphong;
    private String songuoi;
    private String sogiuong;
    private String ngaynhan;
    private String ngaytra;
    private String tienthue;
    private String tongtien;
    private String motaphong;
    private String thanhtoan;
    private String hinh;

    public String getNgaydat() {
        return ngaydat;
    }

    public void setNgaydat(String ngaydat) {
        this.ngaydat = ngaydat;
    }

    private String ngaydat;

    public String getThoihan() {
        return thoihan;
    }

    public void setThoihan(String thoihan) {
        this.thoihan = thoihan;
    }

    private String thoihan;
}
