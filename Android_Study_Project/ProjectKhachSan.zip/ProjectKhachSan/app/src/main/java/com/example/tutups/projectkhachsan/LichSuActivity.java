package com.example.tutups.projectkhachsan;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;


public class LichSuActivity extends AppCompatActivity {
    ActionBarDrawerToggle lichsu_drawertoggle;
    DrawerLayout lichsu_drawerlayout;
    Toolbar lichsu_toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lich_su);

        lichsu_toolbar = findViewById(R.id.lichsu_toolbar);
        setSupportActionBar(lichsu_toolbar);

        lichsu_drawerlayout = findViewById(R.id.lichsu_drawerlayout);
        NavigationView navigationView = findViewById(R.id.lichsu_sidemenu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.sidemenu_timphong:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.lichsu_fragment, new TimPhongFragment()).commit();
                        getSupportActionBar().setTitle("Tìm phòng");
                        break;
                    case R.id.sidemenu_thongtin:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.lichsu_fragment, new ThongTinFragment()).commit();
                        getSupportActionBar().setTitle("Thông tin tài khoản");
                        break;
                    case R.id.sidemenu_lichsu:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.lichsu_fragment, new LichSuFragment()).commit();
                        getSupportActionBar().setTitle("Lịch sử giao dịch");
                        break;
                    case R.id.sidemenu_thongbao:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.lichsu_fragment, new ThongBaoFragment()).commit();
                        getSupportActionBar().setTitle("Thông báo");
                        break;
                    case R.id.sidemenu_hotro:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.lichsu_fragment, new HoTroFragment()).commit();
                        getSupportActionBar().setTitle("Hỗ trợ");
                        break;
                    case R.id.sidemenu_vechungtoi:
                        getSupportFragmentManager().beginTransaction().
                                replace(R.id.lichsu_fragment, new VeChungToiFragment()).commit();
                        getSupportActionBar().setTitle("Về chúng tôi");
                        break;
                }
                item.setChecked(true);
                lichsu_drawerlayout.closeDrawers();
                return true;
            }
        });

        lichsu_drawertoggle = new ActionBarDrawerToggle(LichSuActivity.this, lichsu_drawerlayout, lichsu_toolbar,
                R.string.mo_side_menu, R.string.dong_side_menu);
        lichsu_drawerlayout.addDrawerListener(lichsu_drawertoggle);
        lichsu_drawertoggle.syncState();

        getSupportFragmentManager().beginTransaction().replace(R.id.lichsu_fragment, new LichSuFragment()).commit();
        navigationView.setCheckedItem(R.id.sidemenu_lichsu);
        getSupportActionBar().setTitle("Lịch sử giao dịch");

    }

    @Override
    public void onBackPressed() {
        if (lichsu_drawerlayout.isDrawerOpen(GravityCompat.START)) {
            lichsu_drawerlayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
