package com.example.tutups.projectkhachsan;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class ThongBaoAdapter extends RecyclerView.Adapter<ThongBaoAdapter.ViewHolder> {
    private Context context;
    private ArrayList<ThongBao> thongBaoArrayList;

    public ThongBaoAdapter(Context context, ArrayList<ThongBao> thongBaoArrayList) {
        this.context = context;
        this.thongBaoArrayList = thongBaoArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_thongbao,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ThongBao tb = thongBaoArrayList.get(position);
        holder.txtThongBao.setText(""+ tb.getNoidung() + "\n");
    }

    @Override
    public int getItemCount() {
        return thongBaoArrayList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txtThongBao;
        public TextView txtSoLuong;
        public TextView showNoti;
        public ViewHolder(View itemView) {
            super(itemView);
            txtThongBao = itemView.findViewById(R.id.item_textViewThongBao);
            txtSoLuong = itemView.findViewById(R.id.textViewSoLuongThongBao);
            showNoti = itemView.findViewById(R.id.textView24);
        }
    }

}
