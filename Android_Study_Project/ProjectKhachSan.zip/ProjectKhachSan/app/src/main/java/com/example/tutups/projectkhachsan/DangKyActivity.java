package com.example.tutups.projectkhachsan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DangKyActivity extends AppCompatActivity {
    Button dangky_buttonXacNhan, dangky_buttonTroVe;
    EditText dangky_editTextEmail, dangky_editTextMatKhau, dangky_editTextNhapLai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ky);

        dangky_buttonXacNhan = findViewById(R.id.dangky_buttonXacNhan);
        dangky_buttonTroVe = findViewById(R.id.dangky_buttonTroVe);
        dangky_editTextEmail = findViewById(R.id.dangky_editTextEmail);
        dangky_editTextMatKhau = findViewById(R.id.dangky_editTextMatKhau);
        dangky_editTextNhapLai = findViewById(R.id.dangky_editTextNhapLai);

        dangky_buttonXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = dangky_editTextEmail.getText().toString().trim();
                String matkhau = dangky_editTextMatKhau.getText().toString().trim();
                String nhaplai = dangky_editTextNhapLai.getText().toString().trim();
                ArrayList<String> danhsach_loi = new ArrayList<>();
                if(email.isEmpty() || matkhau.isEmpty() || nhaplai.isEmpty()){
                    danhsach_loi.add("Vui lòng nhập đủ thông tin");
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    danhsach_loi.add("Email không hợp lệ");
                }
                if(!matkhau.equals(nhaplai)){
                    danhsach_loi.add("Nhập lại mật khẩu không đúng");
                }
                if(danhsach_loi.size() > 0){
                    StringBuilder stringBuilder = new StringBuilder();
                    for(int i = 0 ; i < danhsach_loi.size(); i++){
                        if(i == danhsach_loi.size()-1){
                            stringBuilder.append(danhsach_loi.get(i));
                        }else{
                            stringBuilder.append(danhsach_loi.get(i)+"\n");
                        }
                    }
                    Toast.makeText(DangKyActivity.this, stringBuilder.toString(), Toast.LENGTH_SHORT).show();
                }else{
                    DangKy();
                }
            }
        });

        dangky_buttonTroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void DangKy(){
        RequestQueue requestQueue = Volley.newRequestQueue(DangKyActivity.this);
        //String url = "http://192.168.1.16/android/DangKyTaiKhoan.php";
        //String url = "http://192.168.56.1/android/DangKyTaiKhoan.php";
        String url = "http://minh21298.000webhostapp.com/DangKyTaiKhoan.php";
        //String url = "http://192.168.1.3/android/DangKyTaiKhoan.php";
        //String url = "http://192.168.43.125/android/DangKyTaiKhoan.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.trim().equals("success")){
                            Toast.makeText(DangKyActivity.this, "Đăng ký thành công", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(DangKyActivity.this, DangNhapActivity.class));
                        }else{
                            Toast.makeText(DangKyActivity.this, "Đăng ký thất bại", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(DangKyActivity.this, "Lỗi đăng ký", Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("emailTK", dangky_editTextEmail.getText().toString().trim());
                params.put("matkhauTK", dangky_editTextMatKhau.getText().toString().trim());
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
