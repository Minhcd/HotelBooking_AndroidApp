package com.example.tutups.projectkhachsan;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import android.support.v4.app.FragmentManager;

import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.hrules.horizontalnumberpicker.HorizontalNumberPicker;
import com.hrules.horizontalnumberpicker.HorizontalNumberPickerListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TimPhongFragment extends Fragment implements OnMapReadyCallback{
    EditText timphong_editTextNgayNhan, timphong_editTextNgayTra;
    Button timphong_buttonTimPhong;
    HorizontalNumberPicker timphong_numberPickerSoNguoi;
    public static Calendar NgayNhan = Calendar.getInstance();
    public static Calendar NgayTra = Calendar.getInstance();
    private SupportMapFragment mapFragment;
    private GoogleMap mMap;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_timphong, container, false);
        timphong_editTextNgayNhan = view.findViewById(R.id.timphong_editTextNgayNhan);
        timphong_editTextNgayTra = view.findViewById(R.id.timphong_editTextNgayTra);
        timphong_buttonTimPhong = view.findViewById(R.id.timphong_buttonTimPhong);
        timphong_numberPickerSoNguoi = view.findViewById(R.id.timphong_numberPickerSoNguoi);
        timphong_numberPickerSoNguoi.setMinValue(1);
        timphong_numberPickerSoNguoi.setMaxValue(50);

        timphong_editTextNgayNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgayNhan(timphong_editTextNgayNhan);
            }
        });
        timphong_editTextNgayTra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgayTra(timphong_editTextNgayTra);
            }
        });

        timphong_buttonTimPhong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timphong_editTextNgayNhan.getText().toString().equals("") || timphong_editTextNgayTra.getText().toString().equals("")){
                    Toast.makeText(getActivity(), "Xin nhập đủ thông tin", Toast.LENGTH_SHORT).show();
                }
                else if (NgayNhan.get(NgayNhan.DATE) == NgayTra.get(NgayTra.DATE) && NgayNhan.get(NgayNhan.MONTH) == NgayTra.get(NgayTra.MONTH) && NgayNhan.get(NgayNhan.YEAR) == NgayTra.get(NgayTra.YEAR)){
                    Toast.makeText(getActivity(),"Ngày nhận và ngày trả trùng nhau, Xin hãy chọn lại", Toast.LENGTH_LONG).show();
                }
                else if (NgayNhan.get(NgayNhan.DATE) > NgayTra.get(NgayTra.DATE) && NgayNhan.get(NgayNhan.MONTH) == NgayTra.get(NgayTra.MONTH) && NgayNhan.get(NgayNhan.YEAR) == NgayTra.get(NgayTra.YEAR)){
                    Toast.makeText(getActivity(),"Ngày nhận lớn hơn ngày trả, Xin hãy chọn lại", Toast.LENGTH_LONG).show();
                }
                else if (NgayNhan.get(NgayNhan.MONTH) > NgayTra.get(NgayTra.MONTH) && NgayNhan.get(NgayNhan.YEAR) == NgayTra.get(NgayTra.YEAR)){
                    Toast.makeText(getActivity(),"Ngày nhận lớn hơn ngày trả, Xin hãy chọn lại", Toast.LENGTH_LONG).show();
                }
                else if (NgayNhan.get(NgayNhan.YEAR) > NgayTra.get(NgayTra.YEAR)){
                    Toast.makeText(getActivity(),"Ngày nhận lớn hơn ngày trả, Xin hãy chọn lại", Toast.LENGTH_LONG).show();
                }
                else{
                    Intent intent = new Intent(getActivity(), DanhSachPhongActivity.class);
                    intent.putExtra("ngaynhan", timphong_editTextNgayNhan.getText().toString());
                    intent.putExtra("ngaytra", timphong_editTextNgayTra.getText().toString());
                    intent.putExtra("songuoi", timphong_numberPickerSoNguoi.getValue());
                    startActivity(intent);
                }
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        FragmentManager fm = getChildFragmentManager();
        mapFragment = (SupportMapFragment) fm.findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    private void ChonNgayNhan(final EditText editText){
        final Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                NgayNhan.set(year,month,dayOfMonth);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
                editText.setText(simpleDateFormat.format(calendar.getTime()));
            }
        }, nam, thang, ngay);
        datePickerDialog.show();
    }

    private void ChonNgayTra(final EditText editText){
        final Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                NgayTra.set(year,month,dayOfMonth);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
                editText.setText(simpleDateFormat.format(calendar.getTime()));
            }
        }, nam, thang, ngay);
        datePickerDialog.show();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney, Australia, and move the camera.
        LatLng wetravel = new LatLng(10.7613437, 106.6822029);
        mMap.addMarker(new MarkerOptions().position(wetravel).title("WETRAVEL"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(wetravel,15));
    }
}