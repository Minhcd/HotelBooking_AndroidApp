package com.example.tutups.projectkhachsan;

public class ThongBao {
    private int ID;
    private String noidung;

    public ThongBao(int ID, String noidung) {
        this.ID = ID;
        this.noidung = noidung;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNoidung() {
        return noidung;
    }

    public void setNoidung(String noidung) {
        this.noidung = noidung;
    }
}
