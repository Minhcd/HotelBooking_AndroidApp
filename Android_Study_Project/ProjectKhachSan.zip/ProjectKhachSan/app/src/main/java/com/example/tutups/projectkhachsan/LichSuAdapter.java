package com.example.tutups.projectkhachsan;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class LichSuAdapter extends RecyclerView.Adapter<LichSuAdapter.ViewHolder> {
    private Context context;
    private ArrayList<LichSu> lichsuArrayList;
    SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss a");
    Calendar cal  = Calendar.getInstance();
    //Tạo ViewHolder
    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;
        public TextView textViewSoNguoi, textViewSoGiuong, textViewTinhTrang, textViewGiaTien, textViewTenLoaiPhong;
        public TextView textViewNgayNhan, textViewNgayTra, textViewNgayDat, textViewThoiHan;
        public LinearLayout layout;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.item_imageViewItem);
            textViewSoNguoi = itemView.findViewById(R.id.item_textViewSoNguoi);
            textViewSoGiuong = itemView.findViewById(R.id.item_textViewSoGiuong);
            textViewTinhTrang = itemView.findViewById(R.id.item_textViewTinhTrang);
            textViewGiaTien = itemView.findViewById(R.id.item_textViewTongTien);
            textViewTenLoaiPhong = itemView.findViewById(R.id.item_textViewTenLoaiPhong);
            textViewNgayNhan = itemView.findViewById(R.id.item_textViewNgayNhan);
            textViewNgayTra = itemView.findViewById(R.id.item_textViewNgayTra);
            textViewThoiHan = itemView.findViewById(R.id.item_textViewThoiHan);
            textViewNgayDat = itemView.findViewById(R.id.item_textViewNgayDat);
            layout = itemView.findViewById(R.id.item_layout);
        }
    }

    public LichSuAdapter(Context context, ArrayList<LichSu> lichsuArrayList) {
        this.context = context;
        this.lichsuArrayList = lichsuArrayList;
    }

    //3 hàm Override của Recycler View
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lichsu, parent, false);
        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final LichSu p = lichsuArrayList.get(position);
        holder.textViewSoNguoi.setText("Số người: " + p.getSonguoi());
        holder.textViewSoGiuong.setText("Số giường: " + p.getSogiuong());
        holder.textViewGiaTien.setText("Tổng tiền: " + p.getTongtien());
        holder.textViewTenLoaiPhong.setText(p.getLoaiphong());
        Picasso.get().load(p.getHinh()).fit().centerInside().into(holder.imageView);
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar nngaynhan = Calendar.getInstance();
        Calendar nngaytra = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        try {
            nngaynhan.setTime(df.parse(p.getNgaynhan()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        try {
            nngaytra.setTime(df.parse(p.getNgaytra()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String ngaynhan = sdf.format(nngaynhan.getTime());
        String ngaytra = sdf.format(nngaytra.getTime());

        holder.textViewNgayNhan.setText("Ngày nhận: " + ngaynhan);
        holder.textViewNgayTra.setText("Ngày trả: " + ngaytra);
        holder.textViewNgayDat.setText("Ngày đặt: " + p.getNgaydat());
        long th = Long.parseLong(p.getThoihan());
        long diff = cal.getTimeInMillis() - th;
        int seconds = (int) (diff / 1000) % 60 ;
        int minutes = (int) ((diff / (1000*60)) % 60);
        int hours   = (int) ((diff / (1000*60*60)) % 24);
        int days = (int) (hours*0.0416666667);
        if (days > 0)
            holder.textViewThoiHan.setText("Đặt cách đây "+days+" ngày trước");
        else if (hours > 0 && days < 1)
            holder.textViewThoiHan.setText("Đặt cách đây "+hours+" giờ trước");
        else if(minutes > 0 && hours < 1)
            holder.textViewThoiHan.setText("Đặt cách đây "+minutes+" phút trước");
        else if (seconds > 0 && minutes < 1 && hours < 1)
            holder.textViewThoiHan.setText("Đặt cách đây "+seconds+" giây trước");
        if (hours < 24)
            holder.textViewTinhTrang.setText(p.getThanhtoan());
        else
            holder.textViewTinhTrang.setText("Đơn phòng đã quá hạn");
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(context, p.getEmail()+" : "+ p.getHoten() + " : " + p.getSodienthoai(), Toast.LENGTH_LONG).show();
                Toast.makeText(context, "Mô tả phòng: " + p.getMotaphong(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return lichsuArrayList.size();
    }

}
