package com.example.tutups.projectkhachsan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button main_buttonDangNhap, main_buttonDangKy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //startActivity(new Intent(MainActivity.this, TimPhongActivity.class));
        main_buttonDangKy = findViewById(R.id.main_buttonDangKy);
        main_buttonDangNhap = findViewById(R.id.main_buttonDangNhap);

        main_buttonDangKy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DangKyActivity.class));
            }
        });

        main_buttonDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DangNhapActivity.class));
            }
        });
    }
}
