<?php
	include 'Connection.php';
	$db = new Connection();// tạo kết nối
    $email = mysqli_real_escape_string($db->con, $_POST['email']); // lấy dc email cần để cập nhật thông tin
    $hoten = mysqli_real_escape_string($db->con, $_POST['hoten']);
	$sodienthoai = mysqli_real_escape_string($db->con, $_POST['sodienthoai']);
	$diachi = mysqli_real_escape_string($db->con, $_POST['diachi']);
	$tinhthanh = mysqli_real_escape_string($db->con, $_POST['tinhthanh']);
	
    $sql = "UPDATE taikhoan SET hoten = '$hoten', dienthoai = '$sodienthoai', diachi = '$diachi', tinhthanh = '$tinhthanh' WHERE email = '$email'";
    $result = $db->query($sql);
    if($result){
        echo "success";
    }else{
        echo "error";
    }
?>