<?php
    include 'Connection.php';
    class Phong
    {
        public $idloaiphong, $tenloaiphong, $songuoi, $sogiuong, $giatien, $mota, $tinhtrang, $hinh;
        public function __construct($idloaiphong, $tenloaiphong, $songuoi, $sogiuong, $giatien, $mota, $tinhtrang, $hinh) {
            $this->idloaiphong = $idloaiphong;
            $this->tenloaiphong = $tenloaiphong;
            $this->songuoi = $songuoi;
            $this->sogiuong = $sogiuong;
            $this->giatien = $giatien;
            $this->mota = $mota;
            $this->tinhtrang = $tinhtrang;
            $this->hinh = $hinh;
        }
    }

    $db = new Connection();
    $sql = "SELECT * FROM loaiphong";
    $result = $db->query($sql);
    $danhsach_phong = array();
    while($row = mysqli_fetch_assoc($result))
    {
        array_push($danhsach_phong, new Phong($row['idloaiphong'], $row['tenloaiphong'], $row['songuoi']
            ,$row['sogiuong'], $row['giatien'], $row['mota'], $row['tinhtrang'], $row['hinh']));
    }
    echo json_encode($danhsach_phong);
?>