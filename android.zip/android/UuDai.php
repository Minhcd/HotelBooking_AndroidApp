<?php
    include 'Connection.php';
    class UuDai{
        public $ID;
        public $noidung;
    
    public function __construct($id,$nd){
        $this->ID = $id;
        $this->noidung = $nd;
    }
    }
?>