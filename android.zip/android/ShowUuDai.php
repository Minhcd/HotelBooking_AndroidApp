<?php
	include 'UuDai.php';
	$db = new Connection();
	$sql = "SELECT * FROM uudai";
	$result = $db->query($sql);
	$mang = array();
	while($row = mysqli_fetch_assoc($result)){
        array_push($mang,new UuDai($row['ID'], $row['noidung']));
    }
    
    echo json_encode($mang);

?>