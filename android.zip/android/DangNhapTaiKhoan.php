<?php
    include 'TaiKhoan.php';
    $db = new Connection();
    $email = mysqli_real_escape_string($db->con, $_POST['emailTK']);
    $matkhau = mysqli_real_escape_string($db->con, $_POST['matkhauTK']);
    $sql = "SELECT * FROM taikhoan WHERE email = '$email'";
    $result = $db->query($sql);
    if($result){
        if(mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
            if(password_verify($matkhau, $row['matkhau'])){
                echo "success";
            }else{
                echo "wrong_password";
            }
        }else{
            echo "no_email";
        }
    }else{
        echo "error";
    }
?>
