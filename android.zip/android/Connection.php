<?php
    class Connection
    {
        public $con;
        public function __construct() {
            $host = 'localhost';
            $user = 'root';
            $pass = '';
            $database = 'khachsan';
            $this->con = mysqli_connect($host, $user, $pass, $database);
            mysqli_query($this->con, "SET NAMES UTF8");
        }
        public function query($sql)
        {
            return $this->con->query($sql);
        }
    }
?>