<?php
    include 'Connection.php';
    class TaiKhoan{
        public $email;
        public $hoten;
        public $dienthoai;
        public $diachi;
        public $tinhthanh;

        public function __construct($email, $hoten, $dienthoai, $diachi, $tinhthanh) {
            $this->email = $email;
            $this->hoten = $hoten;
            $this->dienthoai = $dienthoai;
            $this->diachi = $diachi;
            $this->tinhthanh = $tinhthanh;
        }
    }
?>