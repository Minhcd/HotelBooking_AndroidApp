<?php
	include 'Connection.php';
	$db = new Connection();// tạo kết nối
    $email = mysqli_real_escape_string($db->con, $_POST['email']); // lấy dc email cần để resetPassword
    $matkhaumoi = mysqli_real_escape_string($db->con, $_POST['matkhaumoi']);
    $hash_matkhaumoi = password_hash($matkhaumoi, PASSWORD_DEFAULT);
    $sql = "UPDATE taikhoan SET matkhau = '$hash_matkhaumoi' WHERE email = '$email'";
    $result = $db->query($sql);
    if($result){
        echo "success";
    }else{
        echo "error";
    }
?>