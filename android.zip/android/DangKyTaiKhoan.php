<?php
    include 'Connection.php';
    $db = new Connection();
    $email = mysqli_real_escape_string($db->con, $_POST['emailTK']);
    $matkhau = mysqli_real_escape_string($db->con, $_POST['matkhauTK']);
    $hash_matkhau = password_hash($matkhau, PASSWORD_DEFAULT);
    $sql = "INSERT INTO taikhoan(email, matkhau, hoten, dienthoai, diachi, tinhthanh) VALUES ('$email', '$hash_matkhau', '', '', '', '')";
    
    if($db->query($sql)){
        echo "success";
    }else{
        echo "error";
    }
?>