<?php
    include 'Connection.php';
    $db = new Connection();
	$Email = $_POST["Email"];
	$HoTen = $_POST["HoTen"];
	$SDT = $_POST["SDT"];
	$LoaiPhong = $_POST["LoaiPhong"];
	$SoNguoi = $_POST["SoNguoi"];
	$SoGiuong = $_POST["SoGiuong"];
	$NgayNhan = $_POST["NgayNhan"];
	$NgayTra = $_POST["NgayTra"];
	$TienThue = $_POST["TienThue"];
	$TongTien = $_POST["TongTien"];
	$MoTa = $_POST["MoTa"];
	$ThanhToan = $_POST["ThanhToan"];
	$Hinh = $_POST["HinhURL"];
	$ThoiHan = $_POST["ThoiHan"];
	$SoPhong = $_POST["SoPhong"];
	$NgayDat = $_POST["NgayDat"];
	$sql = "INSERT INTO datphong(email, hoten, sodienthoai, loaiphong, songuoi, sogiuong, ngaynhan, ngaytra, tienthue, tongtien, motaphong, thanhtoan, hinh, thoihan, sophong, ngaydat) VALUES ('$Email', '$HoTen', '$SDT', '$LoaiPhong', '$SoNguoi', '$SoGiuong', '$NgayNhan', '$NgayTra', '$TienThue', '$TongTien', '$MoTa', '$ThanhToan', '$Hinh', '$ThoiHan', '$SoPhong', '$NgayDat')";
    if($db->query($sql)){
        echo "success";
    }else{
        echo "error";
    }
?>