<?php
    include 'TaiKhoan.php';
    $db = new Connection();
    $email = mysqli_real_escape_string($db->con, $_POST['user_email']);
    //$email = "quoctruong2406@gmail.com";
    $sql = "SELECT * FROM taikhoan WHERE email = '$email'";
    $result = $db->query($sql);
    $row = mysqli_fetch_assoc($result);
    $user = new TaiKhoan($row['email'], $row['hoten'], $row['dienthoai'], $row['diachi'], $row['tinhthanh']);
    echo json_encode($user);
?>