<?php
    include 'Connection.php';
    class LichSu
    {
        public $email, $hoten, $sodienthoai, $loaiphong, $songuoi, $sogiuong, $ngaynhan, $ngaytra, $tienthue, $tongtien, $motaphong, $thanhtoan, $hinh, $thoihan, $ngaydat;
        public function __construct($email, $hoten, $sodienthoai, $loaiphong, $songuoi, $sogiuong, $ngaynhan, $ngaytra, $tienthue, $tongtien, $motaphong, $thanhtoan, $hinh, $thoihan, $ngaydat) {
            $this->email = $email;
            $this->hoten = $hoten;
			$this->sodienthoai = $sodienthoai;
			$this->loaiphong = $loaiphong;
            $this->songuoi = $songuoi;
            $this->sogiuong = $sogiuong;
			$this->ngaynhan = $ngaynhan;
			$this->ngaytra = $ngaytra;
            $this->tienthue = $tienthue;
			$this->tongtien = $tongtien;
            $this->motaphong = $motaphong;
            $this->thanhtoan = $thanhtoan;
            $this->hinh = $hinh;
			$this->thoihan = $thoihan;
			$this->ngaydat = $ngaydat;
        }
    }

    $db = new Connection();
    //$sql = "SELECT * FROM datphong ORDER BY CAST(ngaynhan AS DATE) DESC";
    $sql = "SELECT * FROM datphong ORDER BY CAST(ngaydat AS DATE)";
    $result = $db->query($sql);
    $lichsu = array();
    while($row = mysqli_fetch_assoc($result))
    {
        array_push($lichsu, new LichSu($row['email'], $row['hoten'], $row['sodienthoai']
            ,$row['loaiphong'], $row['songuoi'], $row['sogiuong'], $row['ngaynhan'], $row['ngaytra'], $row['tienthue'], $row['tongtien'], $row['motaphong'], $row['thanhtoan'], $row['hinh'], $row['thoihan'], $row['ngaydat']));
    }
    echo json_encode($lichsu);
?>